import React, { useState } from 'react'
import './App.css'
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

export default function App() {

  let [val, setVal] = useState('');
  let [todos, setTodos] = useState([]);
  let [isEditing, setIsEditing] = useState(false);
  let [indexToEdit, setIndexToEdit] = useState(''); 

  const addItem = () => {
    let newItem = {
      text: val,
      isChecked: false,
    }
    setTodos([...todos, newItem]);
    setVal('');
  }

  const checkItem = (e) => {
    e.isChecked = !e.isChecked;
    setTodos([...todos]);
  }

  const delItem = (i) => {
    todos.splice(i, 1);
    setTodos([...todos]);
  }

  const editItem = (e,i) => {
    setIsEditing(true);
    setIndexToEdit(i);
    setVal(e.text);
  }

  const saveChange = () => {
    todos[indexToEdit].text = val;
    setVal('');
    setTodos([...todos]);
    setIsEditing(false);
  }

  const delAll = () => {
    setTodos([]);
  }

  return (
    <div className='mainBox'>
      <div className='header'>
        TO DO APP
      </div>

      <div className='dataBox'>

        <div className='inputBox'>
          <input value={val} onChange={(e) => { setVal(e.target.value); }} type='text' className='inputStyling'></input>
          <button onClick={isEditing? saveChange : addItem} className='addBtn'><AddCircleOutlineIcon />{isEditing? "Save ": "Add"} </button>
        </div>

        <div className='itemsBox'>
          {
            todos.map((e, i) => {
              return (
                <div className={e.isChecked ? 'item green' : 'item'}  key={i} >
                  <div className='textStyle '>
                    <TaskAltIcon onClick={isEditing? null : () => checkItem(e)} className='icon' />
                    <span>{e.text}</span>
                  </div>
                  <div>
                    <ModeEditIcon onClick={e.isChecked || isEditing ? null : () => editItem(e,i)} className='icon bgBlue' />
                    <HighlightOffIcon  onClick={e.isChecked || isEditing ? null : () => delItem(i)} className='icon bgRed' />
                  </div>
                </div>
              )
            })
          }
        </div>

        <div>
          <button onClick={isEditing? null: delAll} className='delAllBtn'>Delete All</button>
        </div>
      </div>

    </div >
  )
}
